-- SQLite-compatible. No rounded published averages are used in calculations.
SELECT w4.film_id, w4.film,
       w1.weekend_gross_usd AS opening_gross_usd,
       w4.weekend_gross_usd AS week4_gross_usd,
       1.0*w1.weekend_gross_usd/w1.theaters AS opening_per_theater_usd,
       1.0*w4.weekend_gross_usd/w4.theaters AS week4_per_theater_usd,
       1.0*w4.weekend_gross_usd/w1.weekend_gross_usd AS gross_retention,
       1.0*w4.theaters/w1.theaters AS theater_retention,
       (1.0*w4.weekend_gross_usd/w4.theaters)
         /(1.0*w1.weekend_gross_usd/w1.theaters) AS per_theater_retention,
       (SELECT SUM(w.weekend_gross_usd) FROM weekends w
        WHERE w.film_id=w4.film_id) AS four_weekend_gross_usd
FROM weekends w4
JOIN weekends w1 ON w1.film_id=w4.film_id AND w1.release_week=1
WHERE w4.release_week=4
ORDER BY per_theater_retention DESC;
