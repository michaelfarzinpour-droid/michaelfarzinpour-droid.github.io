"""Reproduce the film-retention analysis using the recorded public source rows.

Run: python analyze.py
Uses only the Python standard library. The source is a fixed 2026-10-09 snapshot,
not a live API. To refresh, replace and recheck all four rows for each film.
"""
from pathlib import Path
import csv
import datetime as dt
import json
import math
import sqlite3

ROOT = Path(__file__).resolve().parent
with (ROOT / 'data/film_weekends.csv').open(newline='', encoding='utf-8') as f:
    records = list(csv.DictReader(f))
numeric = ['release_week', 'weekend_gross_usd', 'theaters', 'reported_per_theater_usd']
for r in records:
    for key in numeric:
        r[key] = int(r[key])
    r['reported_change_pct'] = int(r['reported_change_pct']) if r['reported_change_pct'] else None
assert len(records) == 20
assert len({(r['film_id'], r['release_week']) for r in records}) == 20
groups = {}
for r in records:
    assert r['weekend_gross_usd'] > 0 and r['theaters'] > 0
    assert dt.date.fromisoformat(r['weekend_start']).weekday() == 4
    assert abs(r['weekend_gross_usd']/r['theaters'] - r['reported_per_theater_usd']) <= 0.5
    groups.setdefault(r['film_id'], []).append(r)
summary = []
for key, rows in groups.items():
    rows.sort(key=lambda r: r['release_week'])
    assert [r['release_week'] for r in rows] == [1, 2, 3, 4]
    baseline = rows[0]
    for i, r in enumerate(rows):
        assert (dt.date.fromisoformat(r['weekend_start']) - dt.date.fromisoformat(baseline['weekend_start'])).days == i*7
        r['per_theater_usd'] = r['weekend_gross_usd']/r['theaters']
        r['gross_retention'] = r['weekend_gross_usd']/baseline['weekend_gross_usd']
        r['theater_retention'] = r['theaters']/baseline['theaters']
        r['per_theater_retention'] = r['per_theater_usd']/(baseline['weekend_gross_usd']/baseline['theaters'])
        r['week_over_week_change'] = None if i == 0 else r['weekend_gross_usd']/rows[i-1]['weekend_gross_usd']-1
        if i:
            assert abs(r['week_over_week_change']*100-r['reported_change_pct']) <= 0.5
    last = rows[3]
    summary.append({
        'film_id': key, 'film': last['film'],
        'opening_gross_usd': baseline['weekend_gross_usd'],
        'week4_gross_usd': last['weekend_gross_usd'],
        'opening_per_theater_usd': baseline['weekend_gross_usd']/baseline['theaters'],
        'week4_per_theater_usd': last['per_theater_usd'],
        'gross_retention': last['gross_retention'],
        'theater_retention': last['theater_retention'],
        'per_theater_retention': last['per_theater_retention'],
        'four_weekend_gross_usd': sum(r['weekend_gross_usd'] for r in rows)
    })
summary.sort(key=lambda s: s['per_theater_retention'], reverse=True)
con = sqlite3.connect(':memory:')
con.row_factory = sqlite3.Row
con.execute('CREATE TABLE weekends(film_id TEXT, film TEXT, weekend_start TEXT, release_week INTEGER, weekend_gross_usd INTEGER, theaters INTEGER)')
con.executemany('INSERT INTO weekends VALUES (?,?,?,?,?,?)', [tuple(r[k] for k in ['film_id','film','weekend_start','release_week','weekend_gross_usd','theaters']) for r in records])
sql_result = [dict(r) for r in con.execute((ROOT/'analysis.sql').read_text())]
for py, sql in zip(summary, sql_result, strict=True):
    for k, v in py.items():
        if isinstance(v, (int, float)):
            assert math.isclose(v, sql[k], rel_tol=1e-12, abs_tol=1e-9), (k, v, sql[k])
        else:
            assert v == sql[k]
by_id = {r['film_id']: r for r in summary}
elio, horror = by_id['elio'], by_id['28-years-later']
comparison = {
    'elio_opening_gross_vs_28yl': elio['opening_gross_usd']/horror['opening_gross_usd']-1,
    'elio_week4_gross_vs_28yl': elio['week4_gross_usd']/horror['week4_gross_usd']-1,
    'elio_week4_per_theater_vs_28yl': elio['week4_per_theater_usd']/horror['week4_per_theater_usd']-1,
}
with (ROOT / 'data/youtube_trailers.csv').open(newline='', encoding='utf-8') as f:
    trailers = list(csv.DictReader(f))
assert len(trailers) == 2
assert len({r['video_id'] for r in trailers}) == 2
for r in trailers:
    r['reported_views'] = int(r['reported_views'])
    assert r['reported_views'] > 0
    assert r['film_id'] in by_id
    assert dt.date.fromisoformat(r['published_date']) < dt.date.fromisoformat(groups[r['film_id']][0]['weekend_start'])
    assert r['source_url'] == 'https://www.youtube.com/watch?v=' + r['video_id']
trailer_by_id = {r['film_id']: r for r in trailers}
social = {
    'scope': 'Two selected official English-language YouTube trailers; reported cumulative viewing activity.',
    'retrieved_date': '2026-10-09',
    'refresh_time': 'Unavailable; search-reported counts are not a live observation.',
    'records': trailers,
    'view_difference': trailer_by_id['28-years-later']['reported_views'] / trailer_by_id['f1']['reported_views'] - 1,
    'publication_gap_days': (dt.date.fromisoformat(trailer_by_id['f1']['published_date']) - dt.date.fromisoformat(trailer_by_id['28-years-later']['published_date'])).days,
    'recommendation': 'Present opening scale and week-four retention in a client pitch. Before a film/sports brand or creator pitch around F1, request recent organic viewing, audience geography and audience overlap; cumulative trailer views alone cannot establish fit.',
    'limits': [
        'Counts were retrieved in October 2026 from public search results; their underlying refresh times are unavailable. They are not pre-release 2025 observations.',
        'Uploads differ in publication date, channel audience, genre and unknown paid distribution. No exposure-adjusted or causal comparison is supported.',
        'Views are plays, not unique people. Geography, watch time, paid/organic split, audience demographics and conversion are unavailable.',
        'Only two selected official uploads are included; this is not campaign-level reach or cross-platform social listening.'
    ]
}
output = {
    'title': 'Summer Film Demand and Retention',
    'created_date': '2026-10-09', 'source_retrieved_date': '2026-10-09',
    'market': 'United States and Canada', 'currency': 'USD',
    'data_period': '2025-06-13 through 2025-07-20',
    'scope': 'Five selected wide June 2025 releases; first four reported weekends for each; 20 film-weekend rows.',
    'records': records, 'summary': summary, 'comparison': comparison, 'social': social,
    'checks': {'rows': len(records), 'films': len(summary), 'duplicate_keys': 0, 'complete_four_week_runs': True, 'published_average_and_change_checks': True, 'python_sql_reconciliation': True},
    'limits': [
        'Purposive five-film case study, not a representative market sample.',
        'Per-theater revenue adjusts for the number of venues, not showtimes, seats, pricing, premium format mix or which venues remain.',
        'First-weekend grosses retain the publisher convention, including previews. Release dates, genre, holidays and competing films differ.',
        'Revenue retention is a theatrical demand proxy. It does not identify unique viewers, demographics, social engagement, profitability or marketing causation. Trailer views are a separate observation with different timing and geography.',
        'Four-weekend gross is the sum of four weekend figures only; it excludes weekdays and is not cumulative box office.'
    ]
}
(ROOT/'results.json').write_text(json.dumps(output, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'comparison': comparison, 'checks': output['checks'], 'social': social}, indent=2))
