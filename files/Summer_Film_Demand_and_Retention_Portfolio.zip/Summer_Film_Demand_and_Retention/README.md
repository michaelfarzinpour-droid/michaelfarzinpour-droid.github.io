# Summer Film Demand and Retention

Prepared for Michael Farzinpour's analytics portfolio in October 2026.

## Business question

Which of five selected June 2025 wide film releases sustained theatrical demand through their fourth weekend? What should an agent include in a client pitch when opening size, later revenue, and public trailer viewing activity describe different parts of the story?

## Data and reproduction

The source is The Numbers' public domestic weekend performance tables, covering the United States and Canada in USD. The analysis retains the first four reported weekends for F1: The Movie, 28 Years Later, Elio, M3GAN 2.0, and How to Train Your Dragon. This is a selected case study, not an exhaustive June release cohort or a representative sample.

`data/film_weekends.csv` contains 20 recorded source rows and a source URL for each row. The `sources` folder preserves the relevant table excerpts and retrieval date. Published averages and percentage changes are rounded; the calculations use exact gross and theater counts.

`data/youtube_trailers.csv` records reported cumulative views for two selected official English-language trailers: F1: The Movie and 28 Years Later. Both uploads preceded theatrical release, but the counts were retrieved from public search on October 9, 2026. Their underlying refresh times were unavailable. These are search snapshots, not live measurements or historical pre-release counts. Exact video URLs, publisher names, publication dates, and the retrieval evidence are included in `sources/youtube_snapshots.txt`.

Run `python analyze.py` using Python 3.10 or newer. No third-party packages are required. The script checks unique film/week keys, complete four-week sequences, positive gross and venue counts, agreement with the publisher's rounded averages and changes, and independent Python/SQLite reconciliation. `analysis.sql` provides the independent query. `results.json` contains the derived values consumed by the portfolio view.

## Interpretation

Revenue per theater equals weekend gross divided by theater count. Retention equals the current week's value divided by the opening-weekend value. Both measures refer to revenue, not repeat viewers. The four-weekend sum excludes weekday revenue.

Elio and 28 Years Later opened on the same date. Elio's opening was 30.5% smaller, yet its fourth weekend earned 46.2% more in total and 18.2% more per theater. Include opening size and week-four retention together in an agent's client pitch. F1 supplies a separate example of high absolute fourth-weekend per-theater revenue.

The two trailer snapshots report 22.0 million views for F1 and 34.4 million for 28 Years Later. The 28 Years Later upload was published 93 days earlier; the underlying count-refresh times are unknown. This does not support a matched comparison of popularity or conversion. It demonstrates the need to distinguish an upload's reported viewing activity from film attendance.

For a film and sports brand or creator pitch around F1, request recent organic viewing, audience geography, and overlap with the intended brand's customers. Use that evidence to select a creator or brand prospect. Box office and cumulative trailer counts do not establish audience fit or a partnership's financial value.

## Limits

Opening figures retain the publisher's preview convention. Holiday timing, release competition, genre, ticket prices, premium formats and showtimes can affect the comparison. Dividing by theaters does not control for those differences or the changing mix of venues. The project measures theatrical revenue and does not measure profit, marketing ROI or causal audience response.

The YouTube layer contains only two selected uploads, excluding later trailers, regional versions, reuploads and other platforms. Views can include repeat plays and paid distribution; they do not reveal unique viewers, U.S./Canada reach, watch time, demographics, sentiment, conversion or monetization. No cross-platform social listening was performed. Do not regress these snapshots against historical opening grosses or interpret them as evidence that a marketing campaign succeeded or failed.

## Project preparation

Prepared with AI assistance. Recorded source values were checked against published tables, and derived metrics were reconciled through Python, SQLite and Excel. The dashboard and presentation are a portfolio case study and do not represent work performed for CAA or any film distributor.
