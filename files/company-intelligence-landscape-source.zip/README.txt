Company Intelligence Landscape source package

This package contains the current GitHub Pages project page, the decision brief, and its JSON records and source references. The project page loads the JSON file from ../files/company_intelligence_landscape.json and links to brief.html. The public portfolio home is https://michaelfarzinpour-droid.github.io/ and the project page is https://michaelfarzinpour-droid.github.io/company-intelligence-landscape/.

The company comparison is a desk-research sample of 30 vendors based on official public product, pricing, and documentation pages. It is not a vendor pilot or market-share estimate.
