"""Behavior checks for the simulation's data-quality and quota rules."""
from copy import deepcopy
import simulate

base = {'response_id':'fixture-1', 'synthetic':True, 'age_group':'18-24',
        'eligible':True, 'attention_pass':True, 'duration_seconds':90,
        'watch_intent':4, 'concept':'Character-led', 'weekly_streaming_hours':12,
        'preferred_genre':'Drama'}
rows = []
for i in range(7):
    row = dict(base, export_row=i+1, response_id=f'fixture-{i+1}')
    rows.append(row)
rows[1]['duration_seconds'] = 89
rows[2]['attention_pass'] = False
rows[3]['eligible'] = False
rows[4]['watch_intent'] = ''
rows[5]['response_id'] = rows[0]['response_id']
rows[6]['duration_seconds'] = 91
clean, flags = simulate.quality_check(rows)
assert [r['export_row'] for r in clean] == [1,7], 'Duration boundary and valid records'
assert [r['primary_reason'] for r in flags] == ['Retained','Below duration threshold','Attention check failure','Eligibility failure','Missing or invalid watch intent','Duplicate response ID','Retained']
summary = simulate.analyze(rows, clean, flags)
assert summary['quotas'][1]['valid_completes'] == 0
assert summary['quotas'][1]['remaining'] == 150, 'Empty quotas must not disappear'
assert not summary['fielding_complete']
assert simulate.generate() == simulate.generate(), 'The seed must reproduce raw data'
original = simulate.generate()
raw = deepcopy(original)
clean, flags = simulate.quality_check(raw)
assert raw == original, 'QA must not change raw input'
strict, _ = simulate.quality_check(raw, min_seconds=300)
assert len(strict) < len(clean), 'Changing the duration rule must affect retained data'
assert len(clean) == 576 and len(raw) == 656
assert len({r['response_id'] for r in clean}) == len(clean)
print('QA boundaries, duplicate handling, empty quotas, reproducibility, and parameter changes passed.')
