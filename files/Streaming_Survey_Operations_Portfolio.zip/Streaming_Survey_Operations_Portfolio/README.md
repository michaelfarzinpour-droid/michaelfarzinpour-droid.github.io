# Streaming Survey Operations Portfolio

**Synthetic data only.** This small prototype demonstrates the operations behind a streaming research study: clean a mock survey export, review quality dispositions, monitor recruiting quotas, produce SQL summaries, and generate a report. It does not establish experience fielding commercial concept tests or managing real panels.

Created with AI assistance in October 2026. All input records, concept descriptions, ratings, and operational failures are generated. No real customer data, Qualtrics account, respondent recruitment, or external API is used. Runtime reporting is deterministic rather than model-generated.

## Run

Python 3 with matplotlib is required. From this folder, run:

```bash
python3 simulate.py
python3 verify.py
```

Open `outputs/Streaming_Survey_Operations_Report.html` in a browser. The chart is embedded, so the report can be shared as one HTML file. The CSVs can be imported into Excel or Tableau. The SQL is SQLite-compatible; the database is included. BigQuery would require adapting the scalar `MAX(0, ...)` to `GREATEST(0, ...)`.

Change `QUOTA`, `MIN_SECONDS`, or the seed in `simulate.py` to explore the effect on recruiting progress and quality flags. This is a prototype configuration, not a validated threshold or real study specification. `research_spec.md` documents definitions and limitations.

## Files to inspect

- `simulate.py`: reproducible generation, QA, SQL reconciliation, chart, and report.
- `verify.py`: boundary, duplicate, missing-data, quota, and reproducibility checks.
- `queries.sql`: independent descriptive SQL summaries.
- `research_spec.md`: data dictionary and operational rules.
- `outputs/`: reproducible datasets, audit trail, report, chart, and SQLite database.

The project proves that the included workflow runs. Interview discussion should distinguish this prototype from real survey execution and client work.

## ChatGPT workflow prototype

The `assistant/` folder provides reusable survey-QC instructions, mock concept toplines, a quota recruitment memo, a structured sample draft, human-review requirements, and a manual model-evaluation plan. The sample drafts were prepared with ChatGPT assistance from the validated synthetic summary. Run `python3 assistant/verify_assistant_draft.py` to reconcile their numerical claims with Python and SQL outputs. This is a prompt/configuration prototype, not a deployed custom GPT, autonomous agent, or enterprise API service. No confidential or real respondent data is used.

## Dashboard example

`dashboard_example/` includes existing Excel and Tableau workbook prototypes based on 5,015 synthetic used-EV marketplace listings. This separate example demonstrates KPI reporting and visualization; it is not an entertainment dataset. The Tableau package contains eight worksheets and a dashboard. Its XML, embedded source data, and package paths were checked here; its rendering in Tableau Public and publication still require review in that application.

## Portfolio publication status

No public GitHub or Tableau Public URL is available yet. This ZIP can be used as a source package for publishing after review. Until an actual public URL exists, do not put an invented or conversation-only URL on a resume.
