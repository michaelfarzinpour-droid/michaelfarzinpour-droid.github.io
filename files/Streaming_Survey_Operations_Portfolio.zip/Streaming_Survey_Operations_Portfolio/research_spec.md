# Streaming Survey Operations Simulation

This is a synthetic portfolio prototype built with AI assistance. It does not contain actual respondents, client data, or a deployed survey. It is separate from Michael Farzinpour's real Trailer Park Group and University of Arizona survey work.

The operational question is whether a mock streaming study has enough quality-approved responses in each age segment to close fielding. A secondary demonstration compares generated watch-intent ratings for two fictional promotion concepts for the same imagined series. No video is displayed and no customer or effectiveness conclusions may be drawn.

The planning target is 600 valid completes: 150 each for ages 18–24, 25–34, 35–44, and 45+. Equal quotas are an illustrative operational choice, not population weights. Generate 640 unique response records and 16 repeated export records using a fixed random seed of 20261007. Intentionally add eligibility, attention, duration, and missing-rating failures to make the QA process visible.

## Mock questionnaire fields

| Field | Definition |
| --- | --- |
| response_id | Synthetic respondent identifier, SIM-0001 onward |
| synthetic | True for every record |
| age_group | Age quota segment |
| eligible | Mock adult-viewer screening result |
| attention_pass | Mock instructional attention-check result |
| duration_seconds | Simulated completion time |
| weekly_streaming_hours | Generated estimate of viewing hours per week |
| preferred_genre | Generated genre preference |
| concept | Randomly allocated fictional promotion concept |
| watch_intent | Generated 1–5 likelihood of watching the imagined series; blank for intentional incomplete cases |

Character-led and Action-led are invented promotional descriptions, not tested trailers. The generator assigns a modest higher rating parameter to Action-led to demonstrate the reporting calculation. That difference is an input assumption, not a discovered result.

## QA and delivery rules

Keep the first exported record of each response ID. Apply one primary disposition in this order: duplicate, ineligible, attention failure, duration below 90 seconds, missing or invalid watch intent, retained. The 90-second threshold is an illustrative parameter, not a validated industry standard. The first-occurrence rule is appropriate to these intentionally copied records; real inconsistent repeat submissions would require case review.

Analyze only retained records. Check the overall target and every quota before marking fielding complete. A segment with zero valid cases must remain visible with its full deficit. Report the raw, clean, and excluded counts together. Keep the raw file unchanged while saving cleaned data and an audit trail separately.

Outputs include raw and clean CSVs, QA flags, a JSON summary, a SQLite database, SQL result CSVs, a chart, and a self-contained HTML report. The narrative report is generated from templates tied to computed results. No AI API is used at runtime; the code itself was created with AI assistance.
