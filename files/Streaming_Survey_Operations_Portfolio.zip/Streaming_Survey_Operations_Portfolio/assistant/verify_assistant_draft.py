"""Reconcile a structured draft against independent Python and SQL source outputs."""
from pathlib import Path
import json
import sqlite3

ROOT = Path(__file__).resolve().parent.parent
summary = json.loads((ROOT / 'outputs/summary.json').read_text())
draft = json.loads((ROOT / 'assistant/examples/structured_draft.json').read_text())
assert summary['synthetic_data'] is True
for key in ['raw_export_rows', 'valid_completes', 'excluded_rows', 'target_valid_completes', 'overall_remaining', 'quota_remaining', 'fielding_complete']:
    assert draft[key] == summary[key], f'Draft disagrees with validated source: {key}'
assert draft['raw_export_rows'] == draft['valid_completes'] + draft['excluded_rows']
with sqlite3.connect(ROOT / 'outputs/survey_operations.sqlite') as conn:
    rows = conn.execute('SELECT q.age_group, MAX(0, q.target - COUNT(r.response_id)) FROM quotas q LEFT JOIN responses_clean r ON r.age_group = q.age_group GROUP BY q.age_group, q.target').fetchall()
    assert dict(rows) == draft['recruitment_valid_completes'], 'Recruitment draft disagrees with SQL'
    assert sum(v for _, v in rows) == draft['quota_remaining']
    concepts = conn.execute('SELECT concept, COUNT(*), SUM(CASE WHEN watch_intent >= 4 THEN 1 ELSE 0 END), AVG(watch_intent) FROM responses_clean GROUP BY concept').fetchall()
    for concept, n, high, mean in concepts:
        item = draft['concepts'][concept]
        assert item['n'] == n and item['top_two_count'] == high
        assert item['top_two_percent'] == round(high / n * 100, 1)
        assert item['mean_watch_intent'] == round(mean, 2)
    rates = {c: high / n * 100 for c, n, high, _ in concepts}
    assert draft['difference_percentage_points'] == round(rates['Action-led'] - rates['Character-led'], 1)
assert draft['external_release_requires_human_review'] is True
assert draft['real_audience_claims_permitted'] is False
print('Draft counts, quota memo, concept denominators, rounding, and review status reconcile with Python and SQL outputs.')
