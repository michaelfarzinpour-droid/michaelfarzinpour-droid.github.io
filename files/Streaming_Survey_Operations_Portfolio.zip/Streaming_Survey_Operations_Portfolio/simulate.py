"""Synthetic streaming survey operations demo. No real respondents or AI API calls."""
from collections import Counter
from pathlib import Path
import base64
import csv
import html
import json
import random
import sqlite3
import statistics

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs'
SEED = 20261007
AGE_GROUPS = ['18-24', '25-34', '35-44', '45+']
QUOTA = 150
MIN_SECONDS = 90
FIELDS = ['export_row', 'response_id', 'synthetic', 'age_group', 'eligible',
          'attention_pass', 'duration_seconds', 'weekly_streaming_hours',
          'preferred_genre', 'concept', 'watch_intent']


def generate():
    rng = random.Random(SEED)
    ages = [a for a in AGE_GROUPS for _ in range(160)]
    concepts = ['Character-led'] * 320 + ['Action-led'] * 320
    rng.shuffle(ages)
    rng.shuffle(concepts)
    order = list(range(640))
    rng.shuffle(order)
    ineligible = set(order[:16])
    inattentive = set(order[16:40])
    fast = set(order[40:56])
    incomplete = set(order[56:64])
    records = []
    for i in range(640):
        hours = round(min(55, max(.5, rng.lognormvariate(2.2, .65))), 1)
        # This concept difference is an arbitrary generation assumption, not a finding.
        latent = 3.1 + .30 * (concepts[i] == 'Action-led') + rng.gauss(0, 1.1)
        intent = max(1, min(5, round(latent)))
        row = dict(zip(FIELDS, [i+1, f'SIM-{i+1:04}', True, ages[i],
                  i not in ineligible, i not in inattentive,
                  rng.randint(35, 80) if i in fast else rng.randint(120, 620),
                  hours, rng.choice(['Drama', 'Comedy', 'Thriller', 'Sci-fi', 'Animation']),
                  concepts[i], '' if i in incomplete else intent]))
        records.append(row)
    good = [i for i in range(640) if i not in set(order[:64])]
    for i in rng.sample(good, 16):
        duplicate = records[i].copy()
        duplicate['export_row'] = len(records) + 1
        records.append(duplicate)
    return records


def quality_check(records, min_seconds=MIN_SECONDS):
    """Keep the first export occurrence of an ID; assign one primary exclusion reason."""
    seen = set()
    clean, flags = [], []
    for row in records:
        rid = row['response_id']
        if rid in seen:
            reason = 'Duplicate response ID'
        elif not row['eligible']:
            reason = 'Eligibility failure'
        elif not row['attention_pass']:
            reason = 'Attention check failure'
        elif row['duration_seconds'] < min_seconds:
            reason = 'Below duration threshold'
        elif row['watch_intent'] not in [1, 2, 3, 4, 5]:
            reason = 'Missing or invalid watch intent'
        else:
            reason = 'Retained'
            clean.append(row.copy())
        seen.add(rid)
        flags.append({'export_row': row['export_row'], 'response_id': rid,
                      'primary_reason': reason, 'retained': reason == 'Retained'})
    return clean, flags


def write_csv(path, records, fields):
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)


def analyze(records, clean, flags):
    counts = Counter(f['primary_reason'] for f in flags)
    quotas = []
    for group in AGE_GROUPS:
        valid = sum(r['age_group'] == group for r in clean)
        quotas.append({'age_group': group, 'target': QUOTA, 'valid_completes': valid,
                       'remaining': max(0, QUOTA-valid),
                       'status': 'Complete' if valid >= QUOTA else 'Open'})
    concepts = []
    for label in ['Character-led', 'Action-led']:
        group = [r for r in clean if r['concept'] == label]
        high = sum(r['watch_intent'] >= 4 for r in group)
        concepts.append({'concept': label, 'n': len(group), 'top_two_count': high,
                         'top_two_rate': high / len(group) if group else None,
                         'mean_watch_intent': statistics.mean(r['watch_intent'] for r in group) if group else None})
    gap = max(0, QUOTA*len(AGE_GROUPS)-len(clean))
    quota_gap = sum(q['remaining'] for q in quotas)
    return {'synthetic_data': True, 'seed': SEED, 'raw_export_rows': len(records),
            'unique_response_ids': len({r['response_id'] for r in records}),
            'valid_completes': len(clean), 'excluded_rows': len(records)-len(clean),
            'target_valid_completes': QUOTA*len(AGE_GROUPS), 'overall_remaining': gap,
            'quota_remaining': quota_gap, 'fielding_complete': gap == 0 and quota_gap == 0,
            'quality_counts': dict(counts), 'quotas': quotas, 'concept_feedback': concepts,
            'limitations': ['All records and ratings are generated, not collected from people.',
                           'Concept effects are embedded in the generator; they cannot support real audience or causal conclusions.',
                           'This prototype does not deploy Qualtrics surveys, recruit a panel, or call an AI API.']}


def database_and_queries(clean, flags, summary):
    db_path = OUT / 'survey_operations.sqlite'
    if db_path.exists():
        db_path.unlink()
    with sqlite3.connect(db_path) as conn:
        conn.execute('CREATE TABLE responses_clean (response_id TEXT PRIMARY KEY, age_group TEXT, concept TEXT, weekly_streaming_hours REAL, watch_intent INTEGER)')
        conn.executemany('INSERT INTO responses_clean VALUES (?,?,?,?,?)',
                         [(r['response_id'], r['age_group'], r['concept'], r['weekly_streaming_hours'], r['watch_intent']) for r in clean])
        conn.execute('CREATE TABLE qa_flags (export_row INTEGER, response_id TEXT, primary_reason TEXT, retained INTEGER)')
        conn.executemany('INSERT INTO qa_flags VALUES (?,?,?,?)',
                         [(r['export_row'], r['response_id'], r['primary_reason'], int(r['retained'])) for r in flags])
        conn.execute('CREATE TABLE quotas (age_group TEXT PRIMARY KEY, target INTEGER)')
        conn.executemany('INSERT INTO quotas VALUES (?,?)', [(a, QUOTA) for a in AGE_GROUPS])
        sql = '\n'.join(line for line in (ROOT / 'queries.sql').read_text(encoding='utf-8').splitlines()
                        if not line.lstrip().startswith('--'))
        statements = [s.strip() for s in sql.split(';') if s.strip()]
        results = []
        for i, statement in enumerate(statements, 1):
            cursor = conn.execute(statement)
            cols = [v[0] for v in cursor.description]
            rows = [dict(zip(cols, r)) for r in cursor.fetchall()]
            write_csv(OUT / f'sql_result_{i}.csv', rows, cols)
            results.append(rows)
        # Independent SQL aggregates must reconcile with the Python report.
        assert {r['primary_reason']: r['row_count'] for r in results[0]} == summary['quality_counts']
        assert sum(r['valid_completes'] for r in results[1]) == len(clean)
        assert sum(r['remaining'] for r in results[1]) == summary['quota_remaining']
        for row in results[2]:
            py = next(c for c in summary['concept_feedback'] if c['concept'] == row['concept'])
            assert row['n'] == py['n'] and row['top_two_count'] == py['top_two_count']


def charts(summary):
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11})
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4), constrained_layout=True)
    qs = summary['quotas']
    axes[0].bar([q['age_group'] for q in qs], [q['valid_completes'] for q in qs], color='#244A69')
    axes[0].axhline(QUOTA, color='#9E4C24', linestyle='--', label='Target 150')
    axes[0].set(title='Recruiting quotas after QA', xlabel='Age group', ylabel='Valid synthetic completes', ylim=(0, 180))
    axes[0].legend(frameon=False)
    for i, q in enumerate(qs):
        axes[0].text(i, q['valid_completes']+3, str(q['valid_completes']), ha='center')
    cs = summary['concept_feedback']
    rates = [(c['top_two_rate'] or 0)*100 for c in cs]
    axes[1].bar([c['concept'] for c in cs], rates, color=['#244A69', '#628A9E'])
    axes[1].set(title='Mock concept feedback', xlabel='Fictional promotion concept', ylabel='Watch intent rated 4 or 5 (%)', ylim=(0, 100))
    for i, c in enumerate(cs):
        axes[1].text(i, rates[i]+3, f"{rates[i]:.1f}%\nn={c['n']}", ha='center')
    for ax in axes:
        ax.spines[['top', 'right']].set_visible(False)
        ax.set_axisbelow(True)
        ax.grid(axis='y', alpha=.15)
    fig.suptitle('Synthetic portfolio simulation — not real audience evidence', fontsize=12)
    fig.savefig(OUT / 'research_dashboard.png', dpi=170, facecolor='white')
    plt.close(fig)


def report(summary):
    qc = summary['quality_counts']
    qa_rows = ''.join(f'<tr><td>{html.escape(k)}</td><td>{v:,}</td></tr>' for k, v in qc.items())
    quota_rows = ''.join(f"<tr><td>{q['age_group']}</td><td>{q['target']}</td><td>{q['valid_completes']}</td><td>{q['remaining']}</td><td>{q['status']}</td></tr>" for q in summary['quotas'])
    concept_rows = ''
    for c in summary['concept_feedback']:
        rate = 'N/A' if c['top_two_rate'] is None else f"{c['top_two_rate']:.1%}"
        mean = 'N/A' if c['mean_watch_intent'] is None else f"{c['mean_watch_intent']:.2f}"
        concept_rows += f"<tr><td>{c['concept']}</td><td>{c['n']}</td><td>{c['top_two_count']}</td><td>{rate}</td><td>{mean}</td></tr>"
    image = base64.b64encode((OUT/'research_dashboard.png').read_bytes()).decode()
    narrative = (f"QA retained {summary['valid_completes']:,} of {summary['raw_export_rows']:,} exported rows "
                 f"and excluded {summary['excluded_rows']:,}. The fielding goal is {summary['target_valid_completes']:,} valid completes. "
                 f"The age quotas require {summary['quota_remaining']:,} additional valid completes in the open segments shown below. "
                 "Use quota deficits to direct additional recruitment before closing the mock study.")
    document = f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Streaming Survey Operations Simulation</title><style>
body{{font:16px/1.55 Arial,sans-serif;color:#162635;background:#fff;margin:0}}main{{max-width:1080px;margin:auto;padding:40px 32px}}h1{{font-size:34px;line-height:1.15;margin:10px 0 12px}}h2{{font-size:22px;margin:32px 0 12px}}.eyebrow{{text-transform:uppercase;font-weight:bold;color:#9e4c24;letter-spacing:.06em}}.lede{{font-size:18px}}table{{border-collapse:collapse;width:100%;margin:14px 0 20px}}th,td{{padding:10px 14px;border-bottom:1px solid #d9e0e6;text-align:left}}th{{background:#eef3f6}}td:not(:first-child),th:not(:first-child){{text-align:right}}img{{width:100%;height:auto}}.note{{color:#4b5a65}}code{{background:#eef3f6;padding:2px 5px}}@media(max-width:600px){{main{{padding:24px 14px}}th,td{{padding:8px 6px;font-size:13px}}}}
</style><main><div class="eyebrow">Synthetic data · Portfolio prototype</div><h1>Streaming Survey Operations</h1>
<p class="lede">A reproducible example of survey export QA, recruiting quota monitoring, SQL summaries, and automated reporting.</p>
<p><strong>All data are generated.</strong> No people were surveyed or recruited for this project. The two fictional promotion concepts describe the same imagined streaming series: Character-led emphasizes relationships; Action-led emphasizes suspense. No actual trailer was shown.</p>
<h2>Fielding review</h2><p>{narrative}</p>
<img src="data:image/png;base64,{image}" alt="Charts of valid synthetic responses by age quota and generated watch-intent ratings by fictional promotion concept">
<h2>Quality checks</h2><p>Keep the first exported occurrence of each response ID. Exclude eligibility failures, attention-check failures, durations below 90 seconds, and missing or invalid watch-intent ratings. Each row receives one primary reason using this order, so the counts reconcile without double counting.</p>
<table><tr><th>Disposition</th><th>Export rows</th></tr>{qa_rows}</table>
<h2>Recruiting quota review</h2><p>Targets are illustrative planning inputs. An overall sample goal does not replace checking every age quota.</p><table><tr><th>Age group</th><th>Target</th><th>Valid</th><th>Remaining</th><th>Status</th></tr>{quota_rows}</table>
<h2>Mock concept feedback</h2><table><tr><th>Concept</th><th>Valid n</th><th>Rated 4 or 5</th><th>Percent</th><th>Mean 1–5</th></tr>{concept_rows}</table>
<p class="note">These differences come from arbitrary settings in the generator. They provide no evidence about real viewers, actual marketing effectiveness, or causation. This is a workflow demonstration, not a fielded concept test.</p>
<h2>Reproduce and inspect</h2><p>The included Python script generates the data and report; SQL independently checks the summary counts. Review <code>simulate.py</code>, <code>queries.sql</code>, <code>research_spec.md</code>, and the raw, clean, and QA CSV exports. The reporting prose is generated from deterministic templates; no AI model or API runs in this workflow.</p></main></html>'''
    (OUT/'Streaming_Survey_Operations_Report.html').write_text(document, encoding='utf-8')


def main():
    OUT.mkdir(exist_ok=True)
    raw = generate()
    clean, flags = quality_check(raw)
    summary = analyze(raw, clean, flags)
    write_csv(OUT/'responses_raw.csv', raw, FIELDS)
    write_csv(OUT/'responses_clean.csv', clean, FIELDS)
    write_csv(OUT/'qa_flags.csv', flags, ['export_row', 'response_id', 'primary_reason', 'retained'])
    (OUT/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    database_and_queries(clean, flags, summary)
    charts(summary)
    report(summary)
    assert len(raw) == len(clean) + sum(v for k, v in summary['quality_counts'].items() if k != 'Retained')
    assert len({r['response_id'] for r in clean}) == len(clean)
    assert all(r['synthetic'] is True for r in raw)
    print(json.dumps({k: summary[k] for k in ['raw_export_rows','valid_completes','excluded_rows','quota_remaining','fielding_complete']}, indent=2))


if __name__ == '__main__':
    main()
