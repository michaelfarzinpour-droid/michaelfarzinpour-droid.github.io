AP ACCESS POWER BI-READY IMPLEMENTATION PACKAGE

Purpose
This package demonstrates a Power BI implementation design for the AP Access and Course-Taking Equity Dashboard. The included model data are synthetic and calibrated to the real project's published 53.7% overall AP-access finding. State, district, and school labels are fictional.

Files
- AP_Access_PowerBI_Ready_Model.xlsx: dashboard preview, model data, dimensions, DAX measures, and refresh/QA controls.
- SchoolData.csv, DimState.csv, DimDistrict.csv: direct Power BI import files.
- PowerBI_Measures.dax: measures to paste into the Power BI model.
- PowerQuery_SchoolData.m: parameterized refresh and typing logic.
- AP_Access_PowerBI_Dashboard_Preview.png: one-page layout preview.

Power BI Desktop steps
1. Import SchoolData.csv, DimState.csv, and DimDistrict.csv.
2. Create one-to-many relationships from DimState[StateCode] and DimDistrict[DistrictID] to SchoolData.
3. Add the DAX measures in PowerBI_Measures.dax.
4. Add slicers for StateName, DistrictName, UnderrepresentedEnrollmentBand, FRLConcentrationBand, and Locale.
5. Build four KPI cards: Grade 12 Schools, AP Offering Schools, AP Access Rate, and NCES Match Rate.
6. Build a state bar chart and demographic-band comparison chart following the preview.
7. Run every control on the Refresh and QA tab and reconcile dashboard totals to the frozen source extract.
8. Save the validated .pbix. Only then change the resume wording from 'Power BI-ready prototype' to 'Power BI dashboard.'

Accurate resume wording now
Designed a Power BI-ready AP-access dashboard prototype with school, district, state, demographic, and locale fields; documented DAX measures, refresh logic, relationships, and validation checks.

Resume wording after native validation
Built a Power BI dashboard with school, district, state, demographic, and locale filters; documented measures, refresh logic, relationships, and validation checks.
