let
    Source = Excel.Workbook(File.Contents(Parameter_WorkbookPath), null, true),
    SchoolData_Table = Source{[Item="SchoolAccessTable",Kind="Table"]}[Data],
    Typed = Table.TransformColumnTypes(SchoolData_Table,{
        {"SchoolID", type text}, {"StateCode", type text}, {"DistrictID", type text},
        {"Grade12Enrollment", Int64.Type}, {"APCoursesOffered", Int64.Type},
        {"APOfferedFlag", Int64.Type}, {"APEnrollment", Int64.Type},
        {"MatchedNCESFlag", Int64.Type}, {"SuppressedFlag", Int64.Type}
    }),
    RequiredKeys = Table.SelectRows(Typed, each [SchoolID] <> null and [StateCode] <> null and [DistrictID] <> null),
    DistinctSchools = Table.Distinct(RequiredKeys, {"SchoolID"})
in
    DistinctSchools
